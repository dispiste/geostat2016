SPANISH INVENTORY OF TERRESTRIAL SPECIES
------------------------------------------

Data downloaded from 
http://www.magrama.gob.es/es/biodiversidad/temas/inventarios-nacionales/inventario-especies-terrestres/inventario-nacional-de-biodiversidad/bdn-ieet-default.aspx

It contains:
-  a SHP file defining a 10x10km grid for the Spanish penninsular area
and the Balearic Islands. The projection of the SHP is ETRS89-UTM30N
(EPSG:25830)
- a MDB database depicting the distribution, abundance and conservation status
of Spanish terrestrial fauna and flora (per specie and per grid cell)

Both datasets are related by the CUARDICULA and CUTM10X10 fields.



