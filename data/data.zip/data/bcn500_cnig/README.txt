Downloaded from http://centrodedescargas.cnig.es/CentroDescargas/index.jsp

Legal notice:

Política de datos:	

Sin perjuicio de lo dispuesto en el marco normativo legal sobre la Propiedad Intelectual en España, el Estado ostenta la propiedad intelectual y todos los derechos sobre la información geográfica generada por el IGN y sobre los servicios propios que utilicen esa información geográfica y sean prestados por el IGN o por el CNIG. En razón de ello, y de la política de datos determinada por el IGN y el CNIG, establecida en la Orden FOM/2807/2015 , el uso de la información de los productos y servicios de datos geográficos definidos en ella, así como sus derivados, conlleva la aceptación implícita por el usuario de las condiciones generales de dicha orden, concretada en la siguiente licencia de uso , compatible con CC-BY 4.0.

Dicha licencia ampara el uso libre y gratuito para cualquier propósito legítimo, siendo la única estricta obligación la de reconocer y mencionar el origen y propiedad de los productos y servicios de información geográfica licenciados como del IGN, según se indica en la citada licencia.

Los productos a descarga bajo el epígrafe «Línea de Costa», «Líneas de Base Rectas» y «Zona Económica Exclusiva en el Mediterráneo Noroccidental», son propiedad del Instituto Hidrográfico de la Marina , y conforme al Real Decreto 1545/2007, de 23 de noviembre, por el que se regula el Sistema Cartográfico Nacional, forman parte del Equipamiento Geográfico de Referencia Nacional. No requieren la aceptación explícita de licencia y su uso tendrá, en cualquier caso, carácter libre y gratuito, siempre que se mencione al Instituto Hidrográfico de la Marina como origen de la información representada (mediante la referencia, «© Instituto Hidrográfico de la Marina»).

Para cualquier cuestión sobre el uso de la información geográfica accesible desde el CdD, el usuario podrá ponerse en contacto con el CNIG a través de la dirección de correo electrónico consulta@cnig.es . El Presidente del CNIG está habilitado para resolver cuantas cuestiones de carácter general se susciten en la aplicación de la citada Orden FOM/2807/2015 así como dictar las instrucciones necesarias para su aplicación.

