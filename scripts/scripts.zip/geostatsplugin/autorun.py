# encoding: utf-8

import gvsig
from gluecode import *
import gluecode

process = gluecode.TestProcess1()
process.selfregister("Scripting")
#process.updateToolbox() #not necessary at startup
